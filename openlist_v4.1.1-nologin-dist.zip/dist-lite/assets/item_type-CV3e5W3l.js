var r=(t=>(t.String="string",t.Select="select",t.Bool="bool",t.Text="text",t.Number="number",t.Float="float",t))(r||{});export{r as T};
